# Personal Finance Manager

A command-line expense tracking application with reports and CSV persistence.

Run using:
```
python main.py
```
