from menu import Menu

if __name__ == "__main__":
    Menu().run()
